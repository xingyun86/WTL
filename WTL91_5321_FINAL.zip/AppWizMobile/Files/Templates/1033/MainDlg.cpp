// [!output WTL_APPWND_FILE].cpp : implementation of the [!output WTL_MAINDLG_CLASS] class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//?ppc
#include "resourceppc.h"
//?sp
#include "resourcesp.h"
//?end

[!if WTL_APPTYPE_DLG]
#include "aboutdlg.h"
[!endif]
#include "[!output WTL_APPWND_FILE].h"

